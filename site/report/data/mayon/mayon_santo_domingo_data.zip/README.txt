Mayon Radar Watch town data: Santo Domingo

town.geojson            Town border (NAMRIA and PSA via OCHA COD-AB, CC BY-IGO)
channels.geojson        Checked channel lines near the town (OpenStreetMap contributors, ODbL 1.0)
flagged_cells.geojson   Flagged cells inside the town for every approved pass, by pair_id (about 20 m squares, EPSG:4326)
passes.csv              Flagged area inside the town for every approved pass, in km², with who reviewed it

Radar results: Mayon Radar Watch and NASA-ISRO NISAR data via ASF, CC BY 4.0. PROVISIONAL products.
Not an official warning. Follow PHIVOLCS and your LGU.
